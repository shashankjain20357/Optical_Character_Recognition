from PIL import Image
import pytesseract as tess
tess.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
img1 = Image.open('sample1.jpg')
img2 = Image.open('sample2.jpg')
text1 = tess.image_to_string(img1)
text2 = tess.image_to_string(img2)
print(text1)
print(text2)
